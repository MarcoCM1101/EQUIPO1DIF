package mx.itesm.appreto2.Model

import android.app.Application

class MyApp : Application() {
    companion object {
        var idEncargado: Int = 0
        var idComedor: Int = 0
        var idUsuario: Int = 0
    }

    override fun onCreate() {
        super.onCreate()
    }
}

package mx.itesm.appreto2.View

import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.google.gson.Gson
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import mx.itesm.appreto2.R
import mx.itesm.appreto2.ViewModel.QrViewModel

class Qr : Fragment() {

    private lateinit var viewModel: QrViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_qr, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this).get(QrViewModel::class.java)

        val btnGeneraQR = view.findViewById<Button>(R.id.btnGeneraQR)
        val txtCurp = view.findViewById<EditText>(R.id.tvCURP)
        val imgQRUsuario = view.findViewById<ImageView>(R.id.imgQRUsuario)

        btnGeneraQR.setOnClickListener {
            val curp = txtCurp.text.toString()
            viewModel.obtenerUsuario(curp)
        }

        viewModel.usuarioLiveData.observe(viewLifecycleOwner, Observer { usuario3 ->
            if (usuario3 != null) {
                val json = Gson().toJson(usuario3)
                println("JSON: $json")
                val bitmap = generateQRCode(json)
                imgQRUsuario.setImageBitmap(bitmap)
            }
        })

        viewModel.isSuccessful.observe(viewLifecycleOwner, Observer { isSuccessful ->
            if (!isSuccessful) {
                Toast.makeText(context, "CURP no registrado", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun generateQRCode(text: String): Bitmap {
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512)
        val width = bitMatrix.width
        val height = bitMatrix.height
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) -16777216 else -1)
            }
        }
        return bitmap
    }
}

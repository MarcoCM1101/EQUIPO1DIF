package mx.itesm.appreto2.Model

data class User(
    val idUsuario: Int,
    val nombre: String,
    val apellido: String,
    val curp: String
) {
    override fun toString(): String {
        return "$nombre $apellido\n$curp"
    }
}
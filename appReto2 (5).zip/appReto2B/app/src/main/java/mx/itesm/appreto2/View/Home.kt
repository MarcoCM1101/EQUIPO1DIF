package mx.itesm.appreto2.View

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.button.MaterialButton
import mx.itesm.appreto2.R

class Home : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        val webView = view.findViewById<WebView>(R.id.webview)
        webView.loadUrl("https://www.difatizapan.gob.mx/")

        // Encuentra el botón en la vista y establece un OnClickListener
        val button = view.findViewById<MaterialButton>(R.id.button4)
        button.setOnClickListener {
            // Navega al fragmento de registro de usuario cuando se hace clic en el botón
            findNavController().navigate(R.id.action_usuarioFrag_to_registroUsuario)
        }

        val surveyButton = view.findViewById<Button>(R.id.button3)
        surveyButton.setOnClickListener {
            val url = "http://54.164.8.30:8080/formulario.html"
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(url)
            startActivity(intent)
        }

        return view
    }
}

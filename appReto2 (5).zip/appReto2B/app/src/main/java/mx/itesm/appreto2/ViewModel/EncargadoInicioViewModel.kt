package mx.itesm.appreto2.ViewModel

import android.app.Activity
import android.util.Log
import mx.itesm.appreto2.Model.User
import okhttp3.*
import org.json.JSONArray
import java.io.IOException

class EncargadoInicioViewModel(private val activity: Activity) {

    private val client = OkHttpClient()
    private val url = "http://54.164.8.30:8080/usuarios"

    fun getUsers(callback: (ArrayList<User>) -> Unit) {
        val request = Request.Builder()
            .url(url)
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("EncargadoInicio", "Error al hacer la petición", e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    Log.e("EncargadoInicio", "Respuesta no exitosa: ${response.code}")
                }

                val responseBody = response.body?.string()
                Log.d("EncargadoInicio", "Respuesta recibida: $responseBody")

                if (responseBody?.startsWith("[") == true && responseBody.endsWith("]")) {
                    val jsonArray = JSONArray(responseBody)

                    val userList = ArrayList<User>()
                    for (i in 0 until jsonArray.length()) {
                        val userJson = jsonArray.getJSONObject(i)
                        val user = User(
                            idUsuario = userJson.getInt("idUsuario"),
                            nombre = userJson.getString("nombre"),
                            apellido = userJson.getString("apellido"),
                            curp = userJson.getString("curp")
                        )
                        userList.add(user)
                    }

                    callback(userList)
                } else {
                    Log.e("EncargadoInicio", "La respuesta de la API no es un JSON válido")
                }
            }
            })
        }
}



package mx.itesm.appreto2.View

import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.URLSpan
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import mx.itesm.appreto2.R
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import java.io.IOException

data class Usuario(val nombre: String, val apellido: String, val edad: Int, val genero: String, val curp: String)

class RegistroUsuario : Fragment(R.layout.fragment_registro_usuario) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spinner: Spinner = view.findViewById(R.id.spinner)
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            arrayOf("Género","Femenino", "Masculino", "Otro")
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        val nombreInput = view.findViewById<EditText>(R.id.nombre_input)
        val apellidoInput = view.findViewById<EditText>(R.id.apellido_input)
        val edadInput = view.findViewById<EditText>(R.id.edad_input)
        val curpInput = view.findViewById<EditText>(R.id.curp_input)
        val confirmarButton = view.findViewById<Button>(R.id.button2)
        val checkBoxTerminos = view.findViewById<CheckBox>(R.id.cbTerminosCondiciones2)

        confirmarButton.setOnClickListener {
            if (checkBoxTerminos.isChecked) {
                val nombre = nombreInput.text.toString()
                val apellido = apellidoInput.text.toString()
                val edad = edadInput.text.toString().toInt()
                val genero = spinner.selectedItem.toString()
                val curp = curpInput.text.toString()

                if (genero != "Género") {
                    if (curp.length == 18) {
                        val usuario = Usuario(nombre, apellido, edad, genero, curp)
                        enviarUsuario(usuario)

                        // Limpia los campos después de enviar la información del usuario
                        nombreInput.setText("")
                        apellidoInput.setText("")
                        edadInput.setText("")
                        curpInput.setText("")
                        spinner.setSelection(0)
                        checkBoxTerminos.setChecked(false)
                    } else {
                        Toast.makeText(requireContext(), "El CURP no es válido, debe tener 18 dígitos.", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(requireContext(), "Debes aceptar los términos y condiciones.", Toast.LENGTH_SHORT).show()
            }
        }

        val textView: TextView = view.findViewById(R.id.textView11)
        val spannableString = SpannableString("¿No conoces tu CURP? Obténlo aquí")
        spannableString.setSpan(
            URLSpan(""),
            0,
            spannableString.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        textView.text = spannableString
        textView.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse("https://consultas.curp.gob.mx/CurpSP/"))
            startActivity(intent)
        }

        val tvTerminosCondiciones2: TextView = view.findViewById(R.id.tvTerminosCondiciones2)

        val spannableStringTerminos2 = SpannableString("Consultar Términos y Condiciones")
        spannableStringTerminos2.setSpan(
            URLSpan("http://54.164.8.30:8080/terminosCondiciones.html"),
            0,
            spannableStringTerminos2.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        tvTerminosCondiciones2.text = spannableStringTerminos2

        tvTerminosCondiciones2.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://54.164.8.30:8080/terminosCondiciones.html"))
            startActivity(intent)
        }

    }

    private fun enviarUsuario(usuario: Usuario) {
        val url = "http://54.164.8.30:8080/InsertUsuario"

        val json = Gson().toJson(usuario)

        val client = OkHttpClient()

        val body = RequestBody.create("application/json; charset=utf-8".toMediaTypeOrNull(), json)

        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    throw IOException("Unexpected code $response")
                }

                println(response.body?.string())

                activity?.runOnUiThread {
                    context?.let {
                        AlertDialog.Builder(it)
                            .setTitle("Registro de usuario")
                            .setMessage("USUARIO REGISTRADO CON ÉXITO")
                            .setPositiveButton(
                                android.R.string.ok,
                                DialogInterface.OnClickListener { dialog, which ->
                                    dialog.dismiss()
                                })
                            .show()
                    }
                }
            }
        })
    }
}

package mx.itesm.appreto2.View

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.fragment.app.Fragment
import mx.itesm.appreto2.Model.MyApp
import mx.itesm.appreto2.R
import mx.itesm.appreto2.ViewModel.EncargadoSettingsViewModel

class encargadoSettings : Fragment(R.layout.fragment_encargado_settings) {

    private val viewModel = EncargadoSettingsViewModel()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val radioGroup = view.findViewById<RadioGroup>(R.id.Estatusbtn)
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val radioButton = view.findViewById<RadioButton>(checkedId)
            val newStatus = if (radioButton.text == "ABIERTO") "Activo" else "Inactivo"
            viewModel.updateStatus(newStatus)
        }

        val btnAdministrarInv = view.findViewById<Button>(R.id.btnAdministrarInv)
        btnAdministrarInv.setOnClickListener {
            val idComedor = MyApp.idComedor
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://54.164.8.30:8080/inventario.html?idComedor=$idComedor"))
            startActivity(intent)
        }

        val btnLlegoInventario = view.findViewById<Button>(R.id.btnLlegoInventario)
        btnLlegoInventario.setOnClickListener {
            AlertDialog.Builder(context).apply {
                setTitle("Confirmación")
                setMessage("¿Estás seguro que llegó inventario?")
                setPositiveButton("Sí") { _, _ ->
                    viewModel.llegoInventario()
                }
                setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                }
            }.create().show()
        }
    }
}

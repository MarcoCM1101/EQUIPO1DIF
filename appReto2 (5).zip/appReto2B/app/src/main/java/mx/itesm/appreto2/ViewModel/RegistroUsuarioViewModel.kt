package mx.itesm.appreto2


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import java.io.IOException

data class Usuario(val nombre: String, val apellido: String, val edad: Int, val genero: String, val curp: String)

class RegistroUsuarioViewModel : ViewModel() {

    fun enviarUsuario(usuario: Usuario) {
        viewModelScope.launch {
            val url = "http://54.164.8.30:8080/InsertUsuario"

            val json = Gson().toJson(usuario)

            val client = OkHttpClient()

            val body = RequestBody.create("application/json; charset=utf-8".toMediaTypeOrNull(), json)

            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    e.printStackTrace()
                }

                override fun onResponse(call: Call, response: Response) {
                    if (!response.isSuccessful) {
                        throw IOException("Unexpected code $response")
                    }

                    println(response.body?.string())
                }
            })
        }
    }
}

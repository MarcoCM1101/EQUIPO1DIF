package mx.itesm.appreto2.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import mx.itesm.appreto2.View.Usuario3

class SharedViewModel : ViewModel() {
    val usuarioLiveData: MutableLiveData<Usuario3?> = MutableLiveData()
}
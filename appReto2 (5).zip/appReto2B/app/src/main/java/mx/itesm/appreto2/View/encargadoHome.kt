package mx.itesm.appreto2.View

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import mx.itesm.appreto2.R
import mx.itesm.appreto2.databinding.FragmentEncargadoHomeBinding

class encargadoHome : Fragment() {
    private lateinit var binding: FragmentEncargadoHomeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentEncargadoHomeBinding.inflate(inflater,container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        replaceFragment(encargadoInicio())

        binding.bottomNavigationView2.setOnItemSelectedListener {

            when(it.itemId) {
                R.id.list -> replaceFragment(encargadoInicio())
                R.id.camera -> replaceFragment(encargadoCamera())
                R.id.addPerson -> replaceFragment(encargadoAddPerson())
                R.id.settings -> replaceFragment(encargadoSettings())

                else ->{

                }
            }
            true
        }
    }

    private fun replaceFragment(fragment: Fragment){
        val fragmentManager = parentFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame_layout_encargado,fragment)
        fragmentTransaction.commit()
    }
}
package mx.itesm.appreto2.ViewModel

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.IOException

class AnunciosViewModel {

    private val client = OkHttpClient()

    suspend fun fetchAnuncios(): JSONArray {
        val request = Request.Builder()
            .url("http://54.164.8.30:8080/anunciosActivos")
            .build()

        return withContext(Dispatchers.IO) {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("Unexpected code $response")
                JSONArray(response.body!!.string())
            }
        }
    }
}

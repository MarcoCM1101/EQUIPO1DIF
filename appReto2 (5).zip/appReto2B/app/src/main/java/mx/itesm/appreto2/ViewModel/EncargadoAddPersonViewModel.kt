package mx.itesm.appreto2.ViewModel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import mx.itesm.appreto2.Model.MyApp
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException

data class Usuario2(val nombre: String, val apellido: String, val edad: Int, val genero: String, val curp: String)

class EncargadoAddPersonViewModel : ViewModel() {

    private val client = OkHttpClient()

    fun enviarUsuario(usuario: Usuario2) {
        val url = "http://54.164.8.30:8080/InsertUsuario"

        val json = Gson().toJson(usuario)

        val body = RequestBody.create("application/json; charset=utf-8".toMediaTypeOrNull(), json)

        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    throw IOException("Unexpected code $response")
                }

                println(response.body?.string())
            }
        })
    }
}

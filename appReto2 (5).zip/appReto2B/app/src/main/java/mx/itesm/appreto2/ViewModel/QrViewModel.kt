package mx.itesm.appreto2.ViewModel

import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import kotlinx.coroutines.launch
import mx.itesm.appreto2.Model.MyApp
import okhttp3.*
import java.io.IOException

data class Usuario3(val nombre: String, val apellido: String, val edad: Int, val genero: String, val curp: String, val idUsuario: Int)

class QrViewModel : ViewModel() {
    val usuarioLiveData: MutableLiveData<Usuario3?> = MutableLiveData()
    val isSuccessful: MutableLiveData<Boolean> = MutableLiveData()

    fun obtenerUsuario(curp: String) {
        viewModelScope.launch {
            val url = "http://54.164.8.30:8080/usuarioCurp/$curp"
            val client = OkHttpClient()
            val request = Request.Builder().url(url).build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    e.printStackTrace()
                    isSuccessful.postValue(false)
                }

                override fun onResponse(call: Call, response: Response) {
                    if (response.isSuccessful) {
                        val json = response.body?.string()
                        val usuario3 = Gson().fromJson(json, Usuario3::class.java)
                        MyApp.idUsuario = usuario3.idUsuario
                        usuarioLiveData.postValue(usuario3)
                        isSuccessful.postValue(true)
                    } else {
                        isSuccessful.postValue(false)
                    }
                }
            })
        }
    }

}
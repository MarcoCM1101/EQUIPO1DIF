package mx.itesm.appreto2

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.zxing.qrcode.encoder.QRCode
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

class pedidos : Fragment() {
    private lateinit var adapter: MyAdapter
    private lateinit var searchView: SearchView
    private lateinit var listView: ListView

    private val client = OkHttpClient()
    private var selectedUserId: String? = null



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {


        val view = inflater.inflate(R.layout.fragment_pedidos, container, false)
        val rbBoton: RadioButton = view.findViewById(R.id.rbDonativo)

        val sharedPreferences = activity?.getSharedPreferences("sharedPrefs", Context.MODE_PRIVATE)
        val selectedUser = sharedPreferences?.getString("SELECTED_USER", "")
        selectedUserId = selectedUser

        // Suponiendo que 'userList' es tu lista de usuarios
        val userList = mutableListOf(selectedUser ?: "")
        adapter = MyAdapter(userList) { clickedUserId ->
            // Actualiza la lista de usuarios cuando se selecciona un usuario
            updateUserList(clickedUserId)
            selectedUserId = clickedUserId
        }

        val recyclerView = view.findViewById<RecyclerView>(R.id.OneUserList)
        recyclerView.layoutManager = LinearLayoutManager(activity)
        recyclerView.adapter = adapter

        val cbComidaExtra = view.findViewById<CheckBox>(R.id.rbComidaExtra)
        searchView = view.findViewById<SearchView>(R.id.Buscador)
        listView = view.findViewById<ListView>(R.id.SecondUserList)

        // Inicialmente ocultar SearchView y ListView
        searchView.visibility = View.GONE
        listView.visibility = View.GONE

        cbComidaExtra.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Mostrar SearchView y ListView cuando cbComidaExtra esté seleccionado (marcado)
                searchView.visibility = View.VISIBLE
                listView.visibility = View.VISIBLE

                // Aquí es donde se maneja la lógica cuando cbComidaExtra está seleccionado.
            } else {
                // Ocultar SearchView y ListView cuando cbComidaExtra no esté seleccionado (desmarcado)
                searchView.visibility = View.GONE
                listView.visibility = View.GONE
            }
        }

        val btnusuarioComedor = view.findViewById<Button>(R.id.btnusuarioComedor)

        btnusuarioComedor.setOnClickListener {
            val donativo = if (rbBoton.isChecked) 1 else 0  // Si rbBoton está seleccionado, donativo será 1, de lo contrario será 0.

            val json = JSONObject()
            json.put("idUsuario", MyApp.idUsuario)
            json.put("idComedor", MyApp.idComedor)
            json.put("donativo", donativo)

            val requestBody = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())

            val request = Request.Builder()
                .url("http://54.164.8.30:8080/InsertUsuarioComedor")
                .post(requestBody)
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e("EncargadoInicio", "Error al hacer la petición", e)
                }

                override fun onResponse(call: Call, response: Response) {
                    if (!response.isSuccessful) {
                        Log.e("EncargadoInicio", "Respuesta no exitosa: ${response.code}")
                    } else {
                        Log.d("EncargadoInicio", "Usuario añadido al comedor con éxito")
                        println(donativo)
                    }
                }
            })
        }

        return view
    }

    private fun updateUserList(newUser: String) {
        adapter.filterUser(newUser)
    }

}

class MyAdapter(private var users: MutableList<String>, private val onItemClickListener: (String) -> Unit) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {

    inner class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView) {
        init {
            textView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val clickedUser = users[position]
                    onItemClickListener(clickedUser)

                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val textView = TextView(parent.context)
        return ViewHolder(textView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView.text = users[position]
    }

    override fun getItemCount() = users.size

    fun filterUser(user: String) {
        users.clear()
        users.add(user)
        notifyDataSetChanged()
    }
}
package mx.itesm.appreto2

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.textfield.TextInputEditText

class EncargadoFrag : Fragment(R.layout.fragment_encargado) {

    private lateinit var viewModel: EncargadoViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = EncargadoViewModel(requireActivity())

        val btnEncargado = view.findViewById<Button>(R.id.button2)
        val usuarioInput = view.findViewById<TextInputEditText>(R.id.usuario_input)
        val contrasenaInput = view.findViewById<TextInputEditText>(R.id.contrasena_input)
        contrasenaInput.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

        btnEncargado.setOnClickListener {
            val usuario = usuarioInput.text.toString()
            val contrasena = contrasenaInput.text.toString()

            viewModel.login(usuario, contrasena) { success ->
                activity?.runOnUiThread {
                    if (success) {
                        findNavController().navigate(R.id.action_EncargadoFrag_to_encargadoHome)
                    } else {
                        Toast.makeText(activity, "Usuario o Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

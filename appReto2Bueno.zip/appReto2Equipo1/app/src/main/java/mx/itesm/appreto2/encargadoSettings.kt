package mx.itesm.appreto2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.fragment.app.Fragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class encargadoSettings : Fragment(R.layout.fragment_encargado_settings) {

    private val client = OkHttpClient()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val radioGroup = view.findViewById<RadioGroup>(R.id.Estatusbtn)
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val radioButton = view.findViewById<RadioButton>(checkedId)
            val newStatus = if (radioButton.text == "ABIERTO") "Activo" else "Inactivo"
            CoroutineScope(Dispatchers.IO).launch {
                updateStatus(newStatus)
            }
        }

        val btnAdministrarInv = view.findViewById<Button>(R.id.btnAdministrarInv)
        btnAdministrarInv.setOnClickListener {
            val idComedor = MyApp.idComedor
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://54.164.8.30:8080/inventario.html?idComedor=$idComedor"))
            startActivity(intent)
        }

        val btnLlegoInventario = view.findViewById<Button>(R.id.btnLlegoInventario)
        btnLlegoInventario.setOnClickListener {
            val idComedor = MyApp.idComedor // Asumiendo que tienes un valor válido para idComedor
            val json = "{\"idComedor\": $idComedor}"

            val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
            val body = json.toRequestBody(mediaType)

            val request = Request.Builder()
                .url("http://54.164.8.30:8080/LlegoInventario")
                .post(body)
                .build()

            CoroutineScope(Dispatchers.IO).launch {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        // Manejar una respuesta no exitosa aquí si es necesario
                        Log.e("API Response", "Unexpected code ${response.code}")
                    } else {
                        // Manejar una respuesta exitosa aquí si es necesario
                        Log.d("API Response", response.body!!.string())
                    }
                }
            }
        }
    }

    private fun updateStatus(newStatus: String) {
        val json = "{\"newStatus\":\"$newStatus\"}"
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("http://54.164.8.30:8080/actualizarEstatusComedor/1")
            .put(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Unexpected code ${response.code}")

            Log.d("API Response", response.body!!.string())
        }
    }
}
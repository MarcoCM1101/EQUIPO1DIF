package mx.itesm.appreto2

import android.app.AlertDialog
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.google.gson.Gson
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import okhttp3.*
import java.io.IOException

data class Usuario3(val nombre: String, val apellido: String, val edad: Int, val genero: String, val curp: String, val idUsuario: Int)

class Qr : Fragment() {

    private val sharedViewModel: SharedViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_qr, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnGeneraQR = view.findViewById<Button>(R.id.btnGeneraQR)
        val txtCurp = view.findViewById<EditText>(R.id.tvCURP)
        val imgQRUsuario = view.findViewById<ImageView>(R.id.imgQRUsuario)

        btnGeneraQR.setOnClickListener {
            val curp = txtCurp.text.toString()
            obtenerUsuario(curp) { usuario3 ->
                if (usuario3 != null) {
                    val json = Gson().toJson(usuario3)
                    println("JSON: $json")
                    val bitmap = generateQRCode(json)
                    imgQRUsuario.setImageBitmap(bitmap)
                } else {
                    AlertDialog.Builder(context)
                        .setTitle("Error")
                        .setMessage("Usuario no registrado")
                        .setPositiveButton(android.R.string.ok) { dialog, _ ->
                            dialog.dismiss()
                        }
                        .show()
                }
            }
        }
    }

    private fun obtenerUsuario(curp: String, callback: (Usuario3?) -> Unit) {
        val url = "http://54.164.8.30:8080/usuarioCurp/$curp"
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                val json = response.body?.string()
                val usuario3 = Gson().fromJson(json, Usuario3::class.java)
                MyApp.idUsuario = usuario3.idUsuario
                sharedViewModel.usuarioLiveData.postValue(usuario3)
                activity?.runOnUiThread { callback(usuario3) }
            }
        })
    }

    private fun generateQRCode(text: String): Bitmap {
        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512)
        val width = bitMatrix.width
        val height = bitMatrix.height
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) -16777216 else -1)
            }
        }
        return bitmap
    }
}
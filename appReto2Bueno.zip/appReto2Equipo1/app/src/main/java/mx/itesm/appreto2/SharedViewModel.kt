package mx.itesm.appreto2

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SharedViewModel : ViewModel() {
    val usuarioLiveData: MutableLiveData<Usuario3?> = MutableLiveData()
}
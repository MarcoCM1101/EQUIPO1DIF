package mx.itesm.appreto2

import android.app.Activity
import android.util.Log
import android.widget.Toast
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class EncargadoViewModel(private val activity: Activity) {

    private val client = OkHttpClient()

    fun login(usuario: String, contrasena: String, callback: (Boolean) -> Unit) {
        Log.d("EncargadoFrag", "Datos enviados a la API: telefono=$usuario, contrasena=$contrasena")

        val requestBody = FormBody.Builder()
            .add("telefono", usuario)
            .add("contrasena", contrasena)
            .build()

        val url = "http://54.164.8.30:8080/loginEncargado/$usuario/$contrasena"
        Log.d("EncargadoFrag", "URL de la API: $url")

        val request = Request.Builder()
            .url(url)
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                activity.runOnUiThread {
                    Toast.makeText(activity, "Usuario o Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                }
                callback(false)
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    Log.e("EncargadoFrag", "Respuesta no exitosa: ${response.code}")
                    activity.runOnUiThread {
                        Toast.makeText(activity, "Usuario o Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                    }
                    callback(false)
                }

                val responseBody = response.body?.string()
                Log.d("EncargadoFrag", "Respuesta recibida: $responseBody")

                if (responseBody?.startsWith("{") == true && responseBody.endsWith("}")) {
                    val json = JSONObject(responseBody)
                    val login = json.getString("login")

                    if (response.isSuccessful && login == "TRUE") {
                        MyApp.idEncargado = json.getInt("idEncargado")
                        MyApp.idComedor = json.getInt("idComedor")
                        callback(true)
                    } else {
                        Log.e("EncargadoFrag", "Error en la respuesta de la API")
                        activity.runOnUiThread {
                            Toast.makeText(activity, "Usuario o Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                        }
                        callback(false)
                    }
                } else {
                    Log.e("EncargadoFrag", "La respuesta de la API no es un JSON válido")
                    callback(false)
                }
            }
        })
    }
}

package mx.itesm.appreto2

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.google.zxing.integration.android.IntentIntegrator
import mx.itesm.appreto2.databinding.FragmentEncargadoCameraBinding
import org.json.JSONObject

class encargadoCamera : Fragment(R.layout.fragment_encargado_camera) {

    private val sharedViewModel: SharedViewModel by activityViewModels()
    private lateinit var binding: FragmentEncargadoCameraBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentEncargadoCameraBinding.inflate(LayoutInflater.from(requireContext()))
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentEncargadoCameraBinding.bind(view)

        sharedViewModel.usuarioLiveData.observe(viewLifecycleOwner) { usuario ->
            usuario?.let {
                binding.tvCodigoQR.text = "CURP: ${usuario.curp}"
                // Puedes agregar más lógica aquí si necesitas mostrar más información del usuario.

            }
        }

        binding.btnQRCode.setOnClickListener {
            val integrator = IntentIntegrator.forSupportFragment(this)
            integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
            integrator.setPrompt("Scan a QR code")
            integrator.initiateScan()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(activity, "Cancelled", Toast.LENGTH_LONG).show()
            } else {
                // Aquí, simplemente estamos mostrando el contenido del QR.
                // Si necesitas procesar esta información, puedes agregar lógica adicional.
                binding.tvCodigoQR.text = "CURP: ${result.contents}"
                val prefs = activity?.getSharedPreferences("sharedPrefs",Context.MODE_PRIVATE)
                prefs!!.edit().apply{
                    val jsonObject = JSONObject(result.contents)
                    println(jsonObject)
                    putString("SELECTED_USER", jsonObject.getString("nombre") + " " + jsonObject.getString("apellido") + "\n" + jsonObject.getString("curp"))
                    putInt("SELECTED_USER_ID", jsonObject.getInt("idUsuario"))
                    commit()

                    MyApp.idUsuario = jsonObject.getInt("idUsuario")
                }
                //if (findNavController().currentDestination?.id == R.id.encargadoCamera) {
                    findNavController().navigate(R.id.action_encargadoHome_to_pedidos)
                //}
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
package mx.itesm.appreto2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.fragment.app.Fragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class Anuncios : Fragment(R.layout.fragment_anuncios) {

    private val client = OkHttpClient()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val facebookButton = view.findViewById<ImageButton>(R.id.imgBtnFacebook)
        facebookButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/AtizapanDIF/"))
            startActivity(intent)
        }

        val twitterButton = view.findViewById<ImageButton>(R.id.imgBtnTwitter)
        twitterButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/difatizapanz?lang=es"))
            startActivity(intent)
        }

        val instagramButton = view.findViewById<ImageButton>(R.id.imgBtnInstagram)
        instagramButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/difatizapanz/?hl=es-la"))
            startActivity(intent)
        }

        val listViewAnuncios = view.findViewById<ListView>(R.id.listViewAnuncios)

        CoroutineScope(Dispatchers.IO).launch {
            val anuncios = fetchAnuncios()
            withContext(Dispatchers.Main) {
                val listItems = ArrayList<String>()
                for (i in 0 until anuncios.length()) {
                    val anuncio = anuncios.getJSONObject(i)
                    listItems.add(anuncio.getString("titulo") + "\n" + anuncio.getString("descripcion"))
                }
                val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, listItems)
                listViewAnuncios.adapter = adapter
            }
        }
    }

    private fun fetchAnuncios(): JSONArray {
        val request = Request.Builder()
            .url("http://54.164.8.30:8080/anunciosActivos")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Unexpected code $response")

            return JSONArray(response.body!!.string())
        }
    }
}
